## Exercise the application

```
curl -X GET http://localhost:8080/greet
{"message":"Hello World!"}
```
